<?php 

$vwipanel = "" // Installation URL of Vesta Web Interface with http(s):// and without trailing slash. 

?>